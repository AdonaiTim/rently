import 'package:flutter/material.dart';
import 'package:unicons/unicons.dart';


class DashboardScreen extends StatelessWidget {
   DashboardScreen({Key? key}) : super(key: key);

  PageController pageController = PageController();


  //[]

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.purpleAccent,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: CircleAvatar(
            backgroundImage: AssetImage('assets/images/portrait.jpg'),
            radius: 20,
            backgroundColor: Colors.orange,
          ),
        ) ,
        title: Text('Dashboard'),
      ),
      body: PageView(
        physics: NeverScrollableScrollPhysics(),
        controller: pageController,
        children: [
          Container(
            height: 500,
            color: Colors.red,
            child: Center(
              child: GestureDetector(

                onTap: (){
                  pageController.jumpToPage(1);
                },

                child: Container(
                  height: 50,
                  width: 200,
                  color: Colors.white,
                  child: Center(child: Text("Move to next page")),
                ),
              ),
            ),
          ),
          Container(
            height: 500,
            color: Colors.yellow,
          ),
          Container(
            height: 500,
            color: Colors.green,
          )
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(UniconsLine.home),
            label: "Home"
          ),
          BottomNavigationBarItem(
            icon: Icon(UniconsLine.user),
            label: "profile"
          ),
          BottomNavigationBarItem(
              icon: Icon(UniconsLine.archive),
              label: "Archive"
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.white,
        onPressed: () {},
        child: Icon(
          UniconsLine.message
        ),
      ),
    );
  }
}


