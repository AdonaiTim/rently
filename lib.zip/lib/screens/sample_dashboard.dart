import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:unicons/unicons.dart';

class SampleDashboard extends StatefulWidget {
  const SampleDashboard({Key? key}) : super(key: key);

  @override
  State<SampleDashboard> createState() => _SampleDashboardState();
}

class _SampleDashboardState extends State<SampleDashboard> with TickerProviderStateMixin{
  int currentIndex = 0;

  PageController pageController = PageController();

  void onPageClicked(int index) {
    print("index received is ");
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer:  const Drawer(
        backgroundColor: Colors.white,
        child: Column(
          children: [
            Row(
              children: [
                Icon(UniconsLine.user)
              ],
            )
          ],
        ),
      ),
      backgroundColor: Colors.white,
      appBar: AppBar(
        // leading: const Padding(
        //   padding: EdgeInsets.symmetric(horizontal: 10),
        //   child: CircleAvatar(
        //     backgroundColor: Colors.orange,
        //     radius: 25,
        //     backgroundImage: AssetImage("assets/images/portrait.jpg"),
        //   ),
        // ),
        title: const Text(
          "Dashboard",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: PageView(
          controller:pageController,
          physics:const NeverScrollableScrollPhysics(),
        children: [
          Container(
            color: Colors.blue,
          ),
          Container(
            color: Colors.orange,
          ),
          Container(
            color: Colors.amber,
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          print("my index is $index");
          setState(() {
            currentIndex = index;
          });
          pageController.jumpToPage(index);
        },
        items: [
          BottomNavigationBarItem(
              icon: Icon(
                UniconsLine.user,
                color: currentIndex == 0 ? Colors.orange : Colors.grey,
              ),
              label: "Account"),
          BottomNavigationBarItem(
              icon: Icon(
                UniconsLine.wallet,
                color: currentIndex == 1 ? Colors.orange : Colors.grey,
              ),
              label: "Wallet"),
          BottomNavigationBarItem(
              icon: Icon(
                UniconsLine.apps,
                color: currentIndex == 2 ? Colors.orange : Colors.grey,
              ),
              label: "Travel"),
        ],
      ),
    );
  }
}
