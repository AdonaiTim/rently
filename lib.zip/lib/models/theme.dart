import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../config/constants.dart';
part 'theme.freezed.dart';

@freezed
class AppTheme with _$AppTheme {
  const factory AppTheme({
    ThemeData? theme,
    @Default(ThemeMode.light) ThemeMode mode,
  }) = _AppTheme;
  const AppTheme._();

  static final ThemeData darkTheme = ThemeData(
    scaffoldBackgroundColor: darkPrimary,
    primaryColor: lightPrimary,
    appBarTheme: const AppBarTheme(
      color: darkPrimary,
      iconTheme: IconThemeData(
        color: Colors.white,
      ),
    ),
    colorScheme: const ColorScheme.dark(
      primary: darkPrimary,
      onPrimary: darkAccentPrimary,
      secondary: darkAccent2Primary,
      brightness: Brightness.dark,
    ),
  );

  static final ThemeData lightTheme = ThemeData(
    scaffoldBackgroundColor: pageBackground,
    primaryColor: lightPrimary,
    brightness: Brightness.light,
    appBarTheme: const AppBarTheme(
      color: pageBackground,
      iconTheme: IconThemeData(
        color: Colors.white,
      ),
    ),
    colorScheme: const ColorScheme.light(
      primary: lightPrimary,
      onPrimary: lightPrimary,
      secondary: lightAccentPrimary,
      brightness: Brightness.light,
    ),
  );

  /*ThemeData? lightTheme(){
    final ThemeData theme = ThemeData.light();
    theme.copyWith(
      primaryColor: lightPrimary,
      brightness: Brightness.light,
      scaffoldBackgroundColor: Colors.yellow,
      backgroundColor: Colors.green
    );
    return theme;
  }*/

}
