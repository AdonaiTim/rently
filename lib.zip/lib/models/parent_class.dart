import 'package:flutter/material.dart';
class AdakuWidget extends StatelessWidget{
  final List<Widget> bags;
  const AdakuWidget({super.key, required this.bags});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        children: bags,
      ) ,
    );
  }

}




