import 'package:flutter/material.dart';
import 'package:rently/config/constants.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../models/theme.dart';
part 'theme_controller.g.dart';

@riverpod
class ThemeController extends _$ThemeController {
  @override
  AppTheme build() {
    return const AppTheme(mode: ThemeMode.light);
  }

  toggleThemeMode() {
    if (state.mode == ThemeMode.light) {
      state = state.copyWith(mode: ThemeMode.dark);
    } else {
      state = state.copyWith(mode: ThemeMode.light);
    }
  }


}
